package TendableProject.TendableProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class TendableAccessibilityTest2 {
	 public static void main(String[] args) {
	        // Set the path to the ChromeDriver executable
	        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

	        // Create a new instance of the ChromeDriver
	        WebDriver driver = new ChromeDriver();

	        // Navigate to the Tendable website
	        driver.get("https://www.tendable.com");

	        // Find and confirm the accessibility of the top-level menus
	        confirmAccessibility(driver, "Home");
	        confirmAccessibility(driver, "Our Story");
	        confirmAccessibility(driver, "Our Solution");
	        confirmAccessibility(driver, "Why Tendable");

	        // Close the browser
	        driver.quit();
	    }

	    private static void confirmAccessibility(WebDriver driver, String menuName) {
	        // Locate the menu element by its link text
	        WebElement menuElement = driver.findElement(By.linkText(menuName));

	        // Click on the menu to navigate to the respective page
	        menuElement.click();

	        // Wait for the page to load (you may need to implement waits as needed)

	        // Find and verify the presence and activity of the "Request a Demo" button
	        WebElement demoButton = driver.findElement(By.xpath("//button[text()='Request a Demo']"));

	        System.out.println("Menu: " + menuName);
	        System.out.println("Is Demo Button Present: " + demoButton.isDisplayed());
	        System.out.println("Is Demo Button Enabled: " + demoButton.isEnabled());
	        System.out.println();

	        // You can perform additional actions on the page if needed and then navigate back to the main page
	        driver.navigate().back();
	    }

}
