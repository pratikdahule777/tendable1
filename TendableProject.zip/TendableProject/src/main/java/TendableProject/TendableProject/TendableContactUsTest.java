package TendableProject.TendableProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class TendableContactUsTest {
	public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\chromedriver.exe");

        // Create a new instance of the ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the Tendable website
        driver.get("https://www.tendable.com");

        // Find and click on the "Contact Us" link
        WebElement contactUsLink = driver.findElement(By.linkText("Contact Us"));
        contactUsLink.click();

        // Wait for the page to load (you may need to implement waits as needed)

        // Choose "Marketing" from the drop-down
        WebElement departmentDropdown = driver.findElement(By.id("department"));
        departmentDropdown.sendKeys("Marketing");

        // Fill out the form excluding the "Message" field
        WebElement nameInput = driver.findElement(By.id("name"));
        nameInput.sendKeys("John Doe");

        WebElement emailInput = driver.findElement(By.id("email"));
        emailInput.sendKeys("john.doe@example.com");

        // Submit the form
        WebElement submitButton = driver.findElement(By.xpath("//button[text()='Submit']"));
        submitButton.click();

        // Wait for the error message to appear
        WebElement errorMessage = driver.findElement(By.xpath("//div[@class='error-message']"));

        // Check if the error message is displayed
        if (errorMessage.isDisplayed()) {
            System.out.println("Test Passed: Error message displayed.");
        } else {
            System.out.println("Test Failed: Error message not displayed.");
        }

        // Close the browser
        driver.quit();
    }

}
