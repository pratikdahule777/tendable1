package TendableProject.TendableProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TendableAccessibilityTest {

    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\chromedriver.exe");

        // Create a new instance of the ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the Tendable website
        driver.get("https://www.tendable.com");

        // Find and confirm the accessibility of the top-level menus
        confirmAccessibility(driver, "Home");
        confirmAccessibility(driver, "Our Story");
        confirmAccessibility(driver, "Our Solution");
        confirmAccessibility(driver, "Why Tendable");

        // Close the browser
        driver.quit();
    }

    private static void confirmAccessibility(WebDriver driver, String menuName) {
        // Locate the menu element by its link text
        WebElement menuElement = driver.findElement(By.linkText(menuName));

        // Output the menu name and check if the element is displayed and enabled
        System.out.println("Menu: " + menuName);
        System.out.println("Is Displayed: " + menuElement.isDisplayed());
        System.out.println("Is Enabled: " + menuElement.isEnabled());
        System.out.println();
    }
}
